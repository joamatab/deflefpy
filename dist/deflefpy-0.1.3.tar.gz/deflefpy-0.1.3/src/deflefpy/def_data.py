"""_summary_
A Python implementation for the DEF data structures.
"""
#TODO
from loguru import logger
from util import Unsupported
import os

def test():
    feat = Unsupported("DEF Data Structures")
    logger.info("{}".format(str(feat)))
    logger.info("Project File: {}".format(os.path.abspath(__file__)))